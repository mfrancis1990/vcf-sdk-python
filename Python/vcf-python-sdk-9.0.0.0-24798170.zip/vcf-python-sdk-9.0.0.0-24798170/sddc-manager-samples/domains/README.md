This directory contains samples for Domains APIs:

Running the samples

    $ python create_domains.py --server <SDDC_MANAGER IP> --user <username> --password <password>

* Testbed Requirement:
   - at least 3 unassigned hosts 
   - add_domain.json : sample parses this file for generating input payload

