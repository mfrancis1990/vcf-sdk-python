# Client Samples

The following table shows the sample sub-directories and their contents.

Directory       | Description
----------------| -------------
cluster         | Samples for Cluster APIs (Add and delete)
domain          | Samples for Domain APIs (Add and delete)
host            | Samples for Host APIs (Add and delete)
