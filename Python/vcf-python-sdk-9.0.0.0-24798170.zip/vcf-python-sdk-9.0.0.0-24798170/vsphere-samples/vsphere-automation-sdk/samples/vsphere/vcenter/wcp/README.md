This directory contains samples for WCP service APIs:

    * Enable supervisor on zones
    * Get/List of supervisor's summary

Running the samples

    $ python <sample-dir>/<sample>.py --server <vCenter Server IP> --username <username> --password <password> <additional-sample-parameters>

* Testbed Requirement:
    - 1 vCenter Server >= 8.0.0+
