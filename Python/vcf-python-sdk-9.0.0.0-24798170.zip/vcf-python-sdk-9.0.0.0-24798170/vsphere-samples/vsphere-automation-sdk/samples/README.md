Directory       | Description
----------------| -------------
vSphere         | Samples for vSphere APIs
vsan            | Samples for vSAN snapservice APIs
