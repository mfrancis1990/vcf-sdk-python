Samples for VCF Installer APIs.
