This directory contains system samples for VCF Installer:


Running sample to get Appliance Info of VCF Installer

    $ python get_appliance_info.py
      --vcf_installer_server_address <VCF_INSTALLER_SERVER_ADDRESS>
      --vcf_installer_admin_password <VCF_INSTALLER_ADMIN_PASSWORD>
      [--ca_certs CA_CERTS]
